//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DmZvRT2C.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/__root.tsx",
		children: [
			"/",
			"/agencies",
			"/area-managers",
			"/inventory",
			"/not-authorised",
			"/orders",
			"/products",
			"/provinces",
			"/sales-reps",
			"/shops",
			"/territories",
			"/records/$entity/$id"
		],
		preloads: ["/assets/index-Cct0RQ1t.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cct0RQ1t.js"
		} }]
	},
	"/": {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DrBSwFTZ.js", "/assets/mock-data-BdjNN9rW.js"]
	},
	"/agencies": {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/agencies.tsx",
		children: void 0,
		preloads: [
			"/assets/agencies-CozraNmz.js",
			"/assets/RouteGuard-CO-4-qai.js",
			"/assets/EntityListPage-VMdOeQGs.js"
		]
	},
	"/area-managers": {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/area-managers.tsx",
		children: void 0,
		preloads: [
			"/assets/area-managers-CjdFcz9u.js",
			"/assets/RouteGuard-CO-4-qai.js",
			"/assets/EntityListPage-VMdOeQGs.js"
		]
	},
	"/inventory": {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/inventory.tsx",
		children: void 0,
		preloads: [
			"/assets/inventory-WTbdcqP6.js",
			"/assets/RouteGuard-CO-4-qai.js",
			"/assets/EntityListPage-VMdOeQGs.js"
		]
	},
	"/not-authorised": {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/not-authorised.tsx",
		children: void 0,
		preloads: ["/assets/not-authorised-Dyulp9K7.js"]
	},
	"/orders": {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/orders.tsx",
		children: void 0,
		preloads: [
			"/assets/orders-DwWOmVhy.js",
			"/assets/RouteGuard-CO-4-qai.js",
			"/assets/EntityListPage-VMdOeQGs.js"
		]
	},
	"/products": {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/products.tsx",
		children: void 0,
		preloads: ["/assets/products-AznhDVXt.js", "/assets/EntityListPage-VMdOeQGs.js"]
	},
	"/provinces": {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/provinces.tsx",
		children: void 0,
		preloads: [
			"/assets/provinces-Dz2f4Crb.js",
			"/assets/RouteGuard-CO-4-qai.js",
			"/assets/EntityListPage-VMdOeQGs.js"
		]
	},
	"/sales-reps": {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/sales-reps.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-reps-ZGkCOukq.js",
			"/assets/RouteGuard-CO-4-qai.js",
			"/assets/EntityListPage-VMdOeQGs.js"
		]
	},
	"/shops": {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/shops.tsx",
		children: void 0,
		preloads: [
			"/assets/shops-1QRcACu1.js",
			"/assets/RouteGuard-CO-4-qai.js",
			"/assets/EntityListPage-VMdOeQGs.js"
		]
	},
	"/territories": {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/territories.tsx",
		children: void 0,
		preloads: [
			"/assets/territories-yJ-zVT8c.js",
			"/assets/RouteGuard-CO-4-qai.js",
			"/assets/EntityListPage-VMdOeQGs.js"
		]
	},
	"/records/$entity/$id": {
		filePath: "D:/Computer Science/year 3/1st semester/CSP/project/sellora/sellora-web/src/routes/records.$entity.$id.tsx",
		children: void 0,
		preloads: ["/assets/records._entity._id-BvBrf1_0.js", "/assets/mock-data-BdjNN9rW.js"]
	}
} });
//#endregion
export { tsrStartManifest };

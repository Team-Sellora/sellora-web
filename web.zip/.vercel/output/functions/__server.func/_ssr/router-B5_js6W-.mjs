import { r as __toESM } from "../_runtime.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as Link, b as useRouter, c as HeadContent, f as createRouter, g as createRootRouteWithContext, h as createFileRoute, m as lazyRouteComponent, p as Outlet, s as Scripts, u as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { c as Package, d as LogOut, f as LayoutDashboard, g as Boxes, h as Building2, l as Map, n as UserCog, o as PanelLeft, p as ClipboardList, r as Store, s as PanelLeftClose, t as Users, u as MapPin } from "../_libs/lucide-react.mjs";
import { r as WebStorageStateStore, t as InMemoryWebStorage } from "../_libs/oidc-client-ts.mjs";
import { n as useAuth, t as AuthProvider } from "../_libs/react-oidc-context.mjs";
import { t as useSelloraAuth } from "./useSelloraAuth-HpYFNrgj.mjs";
import { t as Route$12 } from "./records._entity._id-D_VOYIMN.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-B5_js6W-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function required(value, name) {
	if (!value) throw new Error(`Missing required env var: ${name}`);
	return value;
}
var env = {
	isBaseUrl: required("https://13.61.228.129:9443", "VITE_IS_BASE_URL"),
	gatewayBaseUrl: required("https://13.61.228.129:8244", "VITE_GATEWAY_BASE_URL"),
	oidcClientId: required("ThNL_9YM7zUgl5k6XWXforF1NNga", "VITE_OIDC_CLIENT_ID"),
	appOrigin: required("http://localhost:5173", "VITE_APP_ORIGIN")
};
var oidcConfig = {
	authority: `${env.isBaseUrl}/oauth2/token`,
	metadataUrl: `${env.isBaseUrl}/oauth2/token/.well-known/openid-configuration`,
	client_id: env.oidcClientId,
	redirect_uri: env.appOrigin,
	post_logout_redirect_uri: env.appOrigin,
	response_type: "code",
	scope: "openid profile roles offline_access sellora:ref:read",
	automaticSilentRenew: true,
	accessTokenExpiringNotificationTimeInSeconds: 120,
	userStore: new WebStorageStateStore({ store: new InMemoryWebStorage() })
};
function onSigninCallback(_user) {
	window.history.replaceState({}, document.title, window.location.pathname);
}
function AuthProvider$1({ children }) {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Loading…"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, {
		...oidcConfig,
		onSigninCallback,
		children
	});
}
var styles_default = "/assets/styles-CJPkiosi.css";
var navItems = [
	{
		to: "/",
		label: "Dashboard",
		icon: LayoutDashboard,
		exact: true
	},
	{
		to: "/provinces",
		label: "Provinces",
		icon: Map
	},
	{
		to: "/area-managers",
		label: "Area Managers",
		icon: UserCog
	},
	{
		to: "/agencies",
		label: "Agencies",
		icon: Building2
	},
	{
		to: "/territories",
		label: "Territories",
		icon: MapPin
	},
	{
		to: "/sales-reps",
		label: "Sales Reps",
		icon: Users
	},
	{
		to: "/shops",
		label: "Shops",
		icon: Store
	},
	{
		to: "/products",
		label: "Products",
		icon: Package
	},
	{
		to: "/inventory",
		label: "Inventory",
		icon: Boxes
	},
	{
		to: "/orders",
		label: "Orders",
		icon: ClipboardList
	}
];
function AppShell({ children }) {
	const [collapsed, setCollapsed] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const isActive = (to, exact) => exact ? pathname === to : pathname.startsWith(to);
	const { username, role, logout } = useSelloraAuth();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen w-full bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: cn("fixed inset-y-0 left-0 z-20 flex flex-col border-r border-sidebar-border bg-sidebar transition-[width] duration-200", collapsed ? "w-16" : "w-60"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-14 items-center gap-2 border-b border-sidebar-border px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-7 shrink-0 items-center justify-center rounded bg-primary text-xs font-semibold text-primary-foreground",
						children: "S"
					}), !collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-semibold tracking-tight",
						children: "Sellora"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex-1 space-y-0.5 overflow-y-auto p-2",
					children: navItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						title: item.label,
						className: cn("flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors", isActive(item.to, item.exact) ? "bg-sidebar-accent font-medium text-sidebar-accent-foreground" : "text-sidebar-foreground hover:bg-sidebar-accent/60"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4 shrink-0" }), !collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: item.label
						})]
					}, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setCollapsed((c) => !c),
					className: "flex items-center gap-3 border-t border-sidebar-border px-4 py-3 text-sm text-muted-foreground hover:text-foreground",
					children: collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeft, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeftClose, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Collapse" })] })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("transition-[padding] duration-200", collapsed ? "pl-16" : "pl-60"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-10 flex h-14 items-center justify-between border-b border-border bg-background px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm font-semibold tracking-tight",
					children: ["Sellora ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-normal text-muted-foreground",
						children: "Management Console"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right leading-tight",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-medium",
							children: username ?? "—"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: role ?? "—"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void logout(),
						title: "Log out",
						className: "flex items-center gap-2 rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Log out" })]
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto max-w-7xl px-6 py-8",
				children
			})]
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
function AuthGate({ children }) {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	const auth = useAuth();
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Loading…"
		})
	});
	if (auth.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Loading…"
		})
	});
	if (auth.error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold text-foreground",
					children: "Sign-in error"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: auth.error.message
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-6",
					onClick: () => auth.signinRedirect(),
					children: "Try again"
				})
			]
		})
	});
	if (!auth.isAuthenticated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-sm text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold tracking-tight text-foreground",
					children: "Sellora"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Sign in to access the management console."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-6 w-full",
					onClick: () => auth.signinRedirect(),
					children: "Sign in"
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
/**
* Keeps the in-memory token store in sync with the OIDC auth state.
* Renders nothing — it's a side-effect bridge between React auth and the
* non-React HTTP client.
*/
function TokenSync() {
	const auth = useAuth();
	(0, import_react.useEffect)(() => {
		auth.user?.access_token;
	}, [auth.user?.access_token]);
	(0, import_react.useEffect)(() => {}, [auth]);
	return null;
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$11 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Sellora Management Console" },
			{
				name: "description",
				content: "Internal management console for FMCG field sales and distribution."
			},
			{
				property: "og:title",
				content: "Sellora Management Console"
			},
			{
				property: "og:description",
				content: "Internal management console for FMCG field sales and distribution."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.svg",
				type: "image/svg+xml"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$11.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider$1, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthGate, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenSync, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) })] }) })
	});
}
var $$splitComponentImporter$10 = () => import("./routes-CbxTY6ja.mjs");
var Route$10 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Dashboard — Sellora Management Console" },
		{
			name: "description",
			content: "Overview of agencies, territories, shops and active field reps across the Sellora distribution network."
		},
		{
			property: "og:title",
			content: "Dashboard — Sellora Management Console"
		},
		{
			property: "og:description",
			content: "Overview of agencies, territories, shops and active field reps."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./agencies-DKlYN2Df.mjs");
var Route$9 = createFileRoute("/agencies")({
	head: () => ({ meta: [
		{ title: "Agencies — Sellora" },
		{
			name: "description",
			content: "Manage distribution agencies and their territories."
		},
		{
			property: "og:title",
			content: "Agencies — Sellora"
		},
		{
			property: "og:description",
			content: "Manage distribution agencies and their territories."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./area-managers-BV_sm-jQ.mjs");
var Route$8 = createFileRoute("/area-managers")({
	head: () => ({ meta: [
		{ title: "Area Managers — Sellora" },
		{
			name: "description",
			content: "Manage area managers and their assigned provinces."
		},
		{
			property: "og:title",
			content: "Area Managers — Sellora"
		},
		{
			property: "og:description",
			content: "Manage area managers and their assigned provinces."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./inventory-Bpx-4nDY.mjs");
var Route$7 = createFileRoute("/inventory")({
	head: () => ({ meta: [
		{ title: "Inventory — Sellora" },
		{
			name: "description",
			content: "Track stock on hand and reserved quantities per warehouse."
		},
		{
			property: "og:title",
			content: "Inventory — Sellora"
		},
		{
			property: "og:description",
			content: "Track stock on hand and reserved quantities per warehouse."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./not-authorised-DGh8QYkv.mjs");
var Route$6 = createFileRoute("/not-authorised")({
	head: () => ({ meta: [
		{ title: "Not authorised — Sellora" },
		{
			name: "description",
			content: "You do not have permission to view this page in Sellora."
		},
		{
			property: "og:title",
			content: "Not authorised — Sellora"
		},
		{
			property: "og:description",
			content: "You do not have permission to view this page in Sellora."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./orders-DaZabmwa.mjs");
var Route$5 = createFileRoute("/orders")({
	head: () => ({ meta: [
		{ title: "Orders — Sellora" },
		{
			name: "description",
			content: "Review field sales orders placed by representatives."
		},
		{
			property: "og:title",
			content: "Orders — Sellora"
		},
		{
			property: "og:description",
			content: "Review field sales orders placed by representatives."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./products-CEzCmiuS.mjs");
var Route$4 = createFileRoute("/products")({
	head: () => ({ meta: [
		{ title: "Products — Sellora" },
		{
			name: "description",
			content: "Manage the FMCG product catalogue and pricing."
		},
		{
			property: "og:title",
			content: "Products — Sellora"
		},
		{
			property: "og:description",
			content: "Manage the FMCG product catalogue and pricing."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./provinces-De8GOxIc.mjs");
var Route$3 = createFileRoute("/provinces")({
	head: () => ({ meta: [
		{ title: "Provinces — Sellora" },
		{
			name: "description",
			content: "Manage provinces in the Sellora distribution network."
		},
		{
			property: "og:title",
			content: "Provinces — Sellora"
		},
		{
			property: "og:description",
			content: "Manage provinces in the Sellora distribution network."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./sales-reps-DA1WfFUI.mjs");
var Route$2 = createFileRoute("/sales-reps")({
	head: () => ({ meta: [
		{ title: "Sales Reps — Sellora" },
		{
			name: "description",
			content: "Manage field sales representatives and their territories."
		},
		{
			property: "og:title",
			content: "Sales Reps — Sellora"
		},
		{
			property: "og:description",
			content: "Manage field sales representatives and their territories."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./shops-DYIaiSYb.mjs");
var Route$1 = createFileRoute("/shops")({
	head: () => ({ meta: [
		{ title: "Shops — Sellora" },
		{
			name: "description",
			content: "Manage retail outlets served by the distribution network."
		},
		{
			property: "og:title",
			content: "Shops — Sellora"
		},
		{
			property: "og:description",
			content: "Manage retail outlets served by the distribution network."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./territories-Bdg3n9AD.mjs");
var Route = createFileRoute("/territories")({
	head: () => ({ meta: [
		{ title: "Territories — Sellora" },
		{
			name: "description",
			content: "Manage sales territories and their shop coverage."
		},
		{
			property: "og:title",
			content: "Territories — Sellora"
		},
		{
			property: "og:description",
			content: "Manage sales territories and their shop coverage."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$10.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$11
	}),
	AgenciesRoute: Route$9.update({
		id: "/agencies",
		path: "/agencies",
		getParentRoute: () => Route$11
	}),
	AreaManagersRoute: Route$8.update({
		id: "/area-managers",
		path: "/area-managers",
		getParentRoute: () => Route$11
	}),
	InventoryRoute: Route$7.update({
		id: "/inventory",
		path: "/inventory",
		getParentRoute: () => Route$11
	}),
	NotAuthorisedRoute: Route$6.update({
		id: "/not-authorised",
		path: "/not-authorised",
		getParentRoute: () => Route$11
	}),
	OrdersRoute: Route$5.update({
		id: "/orders",
		path: "/orders",
		getParentRoute: () => Route$11
	}),
	ProductsRoute: Route$4.update({
		id: "/products",
		path: "/products",
		getParentRoute: () => Route$11
	}),
	ProvincesRoute: Route$3.update({
		id: "/provinces",
		path: "/provinces",
		getParentRoute: () => Route$11
	}),
	SalesRepsRoute: Route$2.update({
		id: "/sales-reps",
		path: "/sales-reps",
		getParentRoute: () => Route$11
	}),
	ShopsRoute: Route$1.update({
		id: "/shops",
		path: "/shops",
		getParentRoute: () => Route$11
	}),
	TerritoriesRoute: Route.update({
		id: "/territories",
		path: "/territories",
		getParentRoute: () => Route$11
	}),
	RecordsEntityIdRoute: Route$12.update({
		id: "/records/$entity/$id",
		path: "/records/$entity/$id",
		getParentRoute: () => Route$11
	})
};
var routeTree = Route$11._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };

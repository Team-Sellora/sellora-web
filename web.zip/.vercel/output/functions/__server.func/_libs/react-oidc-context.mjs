import { r as __toESM } from "../_runtime.mjs";
import { n as require_react } from "./@radix-ui/react-compose-refs+[...].mjs";
import { n as UserManager } from "./oidc-client-ts.mjs";
//#region node_modules/react-oidc-context/dist/esm/react-oidc-context.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var AuthContext = import_react.createContext(void 0);
AuthContext.displayName = "AuthContext";
var initialAuthState = {
	isLoading: true,
	isAuthenticated: false
};
var reducer = (state, action) => {
	switch (action.type) {
		case "INITIALISED":
		case "USER_LOADED": return {
			...state,
			user: action.user,
			isLoading: false,
			isAuthenticated: action.user ? !action.user.expired : false,
			error: void 0
		};
		case "USER_SIGNED_OUT":
		case "USER_UNLOADED": return {
			...state,
			user: void 0,
			isAuthenticated: false
		};
		case "NAVIGATOR_INIT": return {
			...state,
			isLoading: true,
			activeNavigator: action.method
		};
		case "NAVIGATOR_CLOSE": return {
			...state,
			isLoading: false,
			activeNavigator: void 0
		};
		case "ERROR": {
			const error = action.error;
			error["toString"] = () => `${error.name}: ${error.message}`;
			return {
				...state,
				isLoading: false,
				error
			};
		}
		default: {
			const innerError = /* @__PURE__ */ new TypeError(`unknown type ${action["type"]}`);
			const error = {
				name: innerError.name,
				message: innerError.message,
				innerError,
				stack: innerError.stack,
				source: "unknown"
			};
			error["toString"] = () => `${error.name}: ${error.message}`;
			return {
				...state,
				isLoading: false,
				error
			};
		}
	}
};
var hasAuthParams = (location = window.location) => {
	let searchParams = new URLSearchParams(location.search);
	if ((searchParams.get("code") || searchParams.get("error")) && searchParams.get("state")) return true;
	searchParams = new URLSearchParams(location.hash.replace("#", "?"));
	if ((searchParams.get("code") || searchParams.get("error")) && searchParams.get("state")) return true;
	return false;
};
var signinError = normalizeErrorFn("signinCallback", "Sign-in failed");
var signoutError = normalizeErrorFn("signoutCallback", "Sign-out failed");
var renewSilentError = normalizeErrorFn("renewSilent", "Renew silent failed");
function normalizeError(error, fallbackMessage) {
	return {
		name: stringFieldOf(error, "name", () => "Error"),
		message: stringFieldOf(error, "message", () => fallbackMessage),
		stack: stringFieldOf(error, "stack", () => (/* @__PURE__ */ new Error()).stack),
		innerError: error
	};
}
function normalizeErrorFn(source, fallbackMessage) {
	return (error) => {
		return {
			...normalizeError(error, fallbackMessage),
			source
		};
	};
}
function stringFieldOf(element, fieldName, or) {
	if (element && typeof element === "object") {
		const value = element[fieldName];
		if (typeof value === "string") return value;
	}
	return or();
}
var userManagerContextKeys = [
	"clearStaleState",
	"querySessionStatus",
	"revokeTokens",
	"startSilentRenew",
	"stopSilentRenew"
];
var navigatorKeys = [
	"signinPopup",
	"signinSilent",
	"signinRedirect",
	"signinResourceOwnerCredentials",
	"signoutPopup",
	"signoutRedirect",
	"signoutSilent"
];
var unsupportedEnvironment = (fnName) => () => {
	throw new Error(`UserManager#${fnName} was called from an unsupported context. If this is a server-rendered page, defer this call with useEffect() or pass a custom UserManager implementation.`);
};
var UserManagerImpl = typeof window === "undefined" ? null : UserManager;
var AuthProvider = (props) => {
	const { children, onSigninCallback, skipSigninCallback, matchSignoutCallback, onSignoutCallback, onRemoveUser, userManager: userManagerProp = null, ...userManagerSettings } = props;
	const [userManager] = import_react.useState(() => {
		return userManagerProp != null ? userManagerProp : UserManagerImpl ? new UserManagerImpl(userManagerSettings) : { settings: userManagerSettings };
	});
	const [state, dispatch] = import_react.useReducer(reducer, initialAuthState);
	const userManagerContext = import_react.useMemo(() => Object.assign({
		settings: userManager.settings,
		events: userManager.events
	}, Object.fromEntries(userManagerContextKeys.map((key) => {
		var _a, _b;
		return [key, (_b = (_a = userManager[key]) == null ? void 0 : _a.bind(userManager)) != null ? _b : unsupportedEnvironment(key)];
	})), Object.fromEntries(navigatorKeys.map((key) => [key, userManager[key] ? async (args) => {
		dispatch({
			type: "NAVIGATOR_INIT",
			method: key
		});
		try {
			return await userManager[key](args);
		} catch (error) {
			dispatch({
				type: "ERROR",
				error: {
					...normalizeError(error, `Unknown error while executing ${key}(...).`),
					source: key,
					args
				}
			});
			return null;
		} finally {
			dispatch({ type: "NAVIGATOR_CLOSE" });
		}
	} : unsupportedEnvironment(key)]))), [userManager]);
	const didInitialize = import_react.useRef(false);
	import_react.useEffect(() => {
		if (!userManager || didInitialize.current) return;
		didInitialize.current = true;
		(async () => {
			try {
				let user = null;
				if (hasAuthParams() && !skipSigninCallback) {
					user = await userManager.signinCallback();
					if (onSigninCallback) await onSigninCallback(user);
				}
				user = !user ? await userManager.getUser() : user;
				dispatch({
					type: "INITIALISED",
					user
				});
			} catch (error) {
				dispatch({
					type: "ERROR",
					error: signinError(error)
				});
			}
			try {
				if (matchSignoutCallback && matchSignoutCallback(userManager.settings)) {
					const resp = await userManager.signoutCallback();
					if (onSignoutCallback) await onSignoutCallback(resp);
				}
			} catch (error) {
				dispatch({
					type: "ERROR",
					error: signoutError(error)
				});
			}
		})();
	}, [
		userManager,
		skipSigninCallback,
		onSigninCallback,
		onSignoutCallback,
		matchSignoutCallback
	]);
	import_react.useEffect(() => {
		if (!userManager) return void 0;
		const handleUserLoaded = (user) => {
			dispatch({
				type: "USER_LOADED",
				user
			});
		};
		userManager.events.addUserLoaded(handleUserLoaded);
		const handleUserUnloaded = () => {
			dispatch({ type: "USER_UNLOADED" });
		};
		userManager.events.addUserUnloaded(handleUserUnloaded);
		const handleUserSignedOut = () => {
			dispatch({ type: "USER_SIGNED_OUT" });
		};
		userManager.events.addUserSignedOut(handleUserSignedOut);
		const handleSilentRenewError = (error) => {
			dispatch({
				type: "ERROR",
				error: renewSilentError(error)
			});
		};
		userManager.events.addSilentRenewError(handleSilentRenewError);
		return () => {
			userManager.events.removeUserLoaded(handleUserLoaded);
			userManager.events.removeUserUnloaded(handleUserUnloaded);
			userManager.events.removeUserSignedOut(handleUserSignedOut);
			userManager.events.removeSilentRenewError(handleSilentRenewError);
		};
	}, [userManager]);
	const removeUser = import_react.useCallback(async () => {
		if (!userManager);
		await userManager.removeUser();
		if (onRemoveUser) await onRemoveUser();
	}, [userManager, onRemoveUser]);
	const contextValue = import_react.useMemo(() => {
		return {
			...state,
			...userManagerContext,
			removeUser
		};
	}, [
		state,
		userManagerContext,
		removeUser
	]);
	return /* @__PURE__ */ import_react.createElement(AuthContext.Provider, { value: contextValue }, children);
};
var useAuth = () => {
	const context = import_react.useContext(AuthContext);
	if (!context) console.warn("AuthProvider context is undefined, please verify you are calling useAuth() as child of a <AuthProvider> component.");
	return context;
};
//#endregion
export { useAuth as n, AuthProvider as t };

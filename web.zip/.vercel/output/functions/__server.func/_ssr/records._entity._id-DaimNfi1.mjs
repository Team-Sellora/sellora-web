import { r as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as getEntity, r as getRecord, t as PageHeader } from "./mock-data-DloGXZJL.mjs";
import { t as Route } from "./records._entity._id-D_VOYIMN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/records._entity._id-DaimNfi1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FormField({ label, error, hint, id, className, ...props }) {
	const fieldId = id ?? props.name ?? label.toLowerCase().replace(/\s+/g, "-");
	let helperText = null;
	if (error) helperText = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs text-destructive",
		children: error
	});
	else if (hint) helperText = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs text-muted-foreground",
		children: hint
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: fieldId,
				className: "block text-sm font-medium",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: fieldId,
				"aria-invalid": !!error,
				className: cn("h-9 w-full rounded-md border bg-background px-3 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:ring-2 focus:ring-ring/40", error ? "border-destructive" : "border-input focus:border-ring", className),
				...props
			}),
			helperText
		]
	});
}
function RecordForm() {
	const { entity: slug, id } = Route.useParams();
	const navigate = useNavigate();
	const entity = getEntity(slug);
	const record = entity && id !== "new" ? getRecord(slug, id) : void 0;
	const [values, setValues] = (0, import_react.useState)(() => {
		const initial = {};
		entity?.fields.forEach((f) => {
			initial[f.key] = record?.[f.key] ?? "";
		});
		initial["status"] = record?.status ?? "Active";
		return initial;
	});
	const [errors, setErrors] = (0, import_react.useState)({});
	if (!entity) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "py-16 text-center text-sm text-muted-foreground",
		children: "Unknown record type."
	});
	const isNew = id === "new";
	const listPath = `/${entity.slug}`;
	const onSubmit = (e) => {
		e.preventDefault();
		const next = {};
		entity.fields.forEach((f) => {
			if (!values[f.key]?.trim()) next[f.key] = `${f.label} is required`;
		});
		setErrors(next);
		if (Object.keys(next).length === 0) navigate({ to: listPath });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: `${isNew ? "New" : "Edit"} ${entity.singular}`,
		description: isNew ? `Create a new ${entity.singular.toLowerCase()} record.` : `Update the details of this ${entity.singular.toLowerCase()}.`,
		crumbs: [{
			label: entity.title,
			to: listPath
		}, { label: isNew ? "New" : "Edit" }]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "max-w-xl space-y-5 rounded-lg border border-border bg-card p-6",
		children: [
			entity.fields.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
				name: f.key,
				label: f.label,
				type: f.type ?? "text",
				value: values[f.key] ?? "",
				error: errors[f.key],
				onChange: (e) => setValues((v) => ({
					...v,
					[f.key]: e.target.value
				}))
			}, f.key)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: "status",
					className: "block text-sm font-medium",
					children: "Status"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					id: "status",
					value: values["status"],
					onChange: (e) => setValues((v) => ({
						...v,
						status: e.target.value
					})),
					className: "h-9 w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "Active",
						children: "Active"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "Inactive",
						children: "Inactive"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 border-t border-border pt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90",
					children: "Save"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: listPath,
					className: "rounded-md border border-input px-4 py-2 text-sm font-medium hover:bg-muted",
					children: "Cancel"
				})]
			})
		]
	})] });
}
//#endregion
export { RecordForm as component };

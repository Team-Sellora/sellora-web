import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as EntityListPage } from "./EntityListPage-X0qwd51i.mjs";
import { t as RouteGuard } from "./RouteGuard-pt2W9FUl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/area-managers-BV_sm-jQ.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RouteGuard, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityListPage, { slug: "area-managers" }) });
//#endregion
export { SplitComponent as component };

import { l as useLocation, v as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as useSelloraAuth } from "./useSelloraAuth-HpYFNrgj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/RouteGuard-pt2W9FUl.js
var import_jsx_runtime = require_jsx_runtime();
var routeAccess = {
	"/provinces": ["CompanyAdmin"],
	"/area-managers": ["CompanyAdmin"],
	"/agencies": ["CompanyAdmin", "AreaManager"],
	"/territories": [
		"CompanyAdmin",
		"AreaManager",
		"AgencyOperator"
	],
	"/sales-reps": [
		"CompanyAdmin",
		"AreaManager",
		"AgencyOperator"
	],
	"/shops": [
		"CompanyAdmin",
		"AreaManager",
		"AgencyOperator",
		"SalesRep"
	],
	"/inventory": [
		"CompanyAdmin",
		"AreaManager",
		"AgencyOperator"
	],
	"/orders": [
		"CompanyAdmin",
		"AreaManager",
		"AgencyOperator",
		"SalesRep"
	]
};
function isRoleAllowed(path, role) {
	const allowed = routeAccess[path];
	if (!allowed) return true;
	if (!role) return false;
	return allowed.includes(role);
}
function RouteGuard({ children }) {
	const { role, isLoading } = useSelloraAuth();
	const location = useLocation();
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-[40vh] items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Loading…"
		})
	});
	if (!isRoleAllowed(location.pathname, role)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/not-authorised" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
//#endregion
export { RouteGuard as t };

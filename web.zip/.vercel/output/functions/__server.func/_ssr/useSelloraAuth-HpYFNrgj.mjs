import { n as useAuth } from "../_libs/react-oidc-context.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useSelloraAuth-HpYFNrgj.js
var KNOWN_ROLES = [
	"CompanyAdmin",
	"AreaManager",
	"AgencyOperator",
	"SalesRep",
	"ShopOwner"
];
/**
* Typed accessor for Sellora auth state.
* Reads decoded claims (role, companyId) from the OIDC token so components
* never parse the token themselves.
*/
function useSelloraAuth() {
	const auth = useAuth();
	const profile = auth.user?.profile;
	const roles = Array.isArray(profile?.roles) ? profile.roles : [];
	const role = KNOWN_ROLES.find((r) => roles.includes(r)) ?? null;
	const companyId = typeof profile?.companyId === "string" ? profile.companyId : null;
	return {
		isAuthenticated: auth.isAuthenticated,
		isLoading: auth.isLoading,
		role,
		roles,
		companyId,
		accessToken: auth.user?.access_token ?? null,
		username: (typeof profile?.preferred_username === "string" ? profile.preferred_username : null) ?? profile?.sub ?? null,
		logout: () => auth.signoutRedirect()
	};
}
//#endregion
export { useSelloraAuth as t };

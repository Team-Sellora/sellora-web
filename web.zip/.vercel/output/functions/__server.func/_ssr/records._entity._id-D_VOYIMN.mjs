import { h as createFileRoute, m as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/records._entity._id-D_VOYIMN.js
var $$splitComponentImporter = () => import("./records._entity._id-DaimNfi1.mjs");
var Route = createFileRoute("/records/$entity/$id")({
	head: () => ({ meta: [
		{ title: "Record details — Sellora" },
		{
			name: "description",
			content: "Create or edit a record in the Sellora management console."
		},
		{
			property: "og:title",
			content: "Record details — Sellora"
		},
		{
			property: "og:description",
			content: "Create or edit a record in the Sellora management console."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };

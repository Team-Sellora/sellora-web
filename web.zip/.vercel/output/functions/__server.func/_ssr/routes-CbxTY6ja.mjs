import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as summaryStats, i as recentActivity, t as PageHeader } from "./mock-data-DloGXZJL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CbxTY6ja.js
var import_jsx_runtime = require_jsx_runtime();
function Dashboard() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Dashboard",
			description: "Snapshot of the field-sales and distribution network."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
			children: summaryStats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border bg-card p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-2xl font-semibold tracking-tight",
					children: stat.value
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 text-sm text-muted-foreground",
					children: stat.label
				})]
			}, stat.label))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8 rounded-lg border border-border bg-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "border-b border-border px-5 py-3 text-sm font-medium",
				children: "Recent activity"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: recentActivity.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-start justify-between gap-4 border-b border-border px-5 py-3 text-sm last:border-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.text }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 text-xs text-muted-foreground",
					children: item.time
				})]
			}, item.id)) })]
		})
	] });
}
//#endregion
export { Dashboard as component };

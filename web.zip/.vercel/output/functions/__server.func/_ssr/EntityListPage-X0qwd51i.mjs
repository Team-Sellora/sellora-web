import { r as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { _ as ArrowUp, a as Plus, v as ArrowUpDown, y as ArrowDown } from "../_libs/lucide-react.mjs";
import { n as getEntity, t as PageHeader } from "./mock-data-DloGXZJL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/EntityListPage-X0qwd51i.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 5;
function SortIcon({ columnKey, sort }) {
	if (sort?.key !== columnKey) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpDown, { className: "size-3" });
	if (sort.dir === "asc") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3" });
}
function DataTable({ columns, rows, loading = false, renderCell, rowActions, searchValue, onSearch, statusFilter, onStatusFilter }) {
	const [sort, setSort] = (0, import_react.useState)(null);
	const [page, setPage] = (0, import_react.useState)(1);
	const sorted = (0, import_react.useMemo)(() => {
		if (!sort) return rows;
		return [...rows].sort((a, b) => {
			const cmp = String(a[sort.key] ?? "").localeCompare(String(b[sort.key] ?? ""), void 0, { numeric: true });
			return sort.dir === "asc" ? cmp : -cmp;
		});
	}, [rows, sort]);
	const totalPages = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
	const currentPage = Math.min(page, totalPages);
	const pageRows = sorted.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
	let tableContent;
	if (loading) tableContent = Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-b border-border last:border-0",
		children: [columns.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
			className: "px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-24 animate-pulse rounded bg-muted" })
		}, col.key)), rowActions && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { className: "px-4 py-3" })]
	}, i));
	else if (pageRows.length === 0) tableContent = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
		colSpan: columns.length + (rowActions ? 1 : 0),
		className: "px-4 py-12 text-center text-sm text-muted-foreground",
		children: "No records found"
	}) });
	else tableContent = pageRows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-b border-border last:border-0 hover:bg-muted/40",
		children: [columns.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
			className: "px-4 py-3",
			children: renderCell ? renderCell(row, col.key) : row[col.key]
		}, col.key)), rowActions && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
			className: "px-4 py-3 text-right",
			children: rowActions(row)
		})]
	}, row.id));
	const toggleSort = (key) => setSort((s) => s?.key === key ? {
		key,
		dir: s.dir === "asc" ? "desc" : "asc"
	} : {
		key,
		dir: "asc"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 border-b border-border p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: searchValue,
						onChange: (e) => {
							onSearch(e.target.value);
							setPage(1);
						},
						placeholder: "Search…",
						className: "h-9 w-64 rounded-md border border-input bg-background px-3 text-sm outline-none placeholder:text-muted-foreground focus:ring-2 focus:ring-ring/40"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: statusFilter,
						onChange: (e) => {
							onStatusFilter(e.target.value);
							setPage(1);
						},
						className: "h-9 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "all",
								children: "All statuses"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Active",
								children: "Active"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Inactive",
								children: "Inactive"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-auto text-xs text-muted-foreground",
						children: [
							sorted.length,
							" record",
							sorted.length === 1 ? "" : "s"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border bg-muted/50 text-left",
						children: [columns.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2.5 font-medium text-muted-foreground",
							children: col.sortable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => toggleSort(col.key),
								className: "inline-flex items-center gap-1 hover:text-foreground",
								children: [col.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortIcon, {
									columnKey: col.key,
									sort
								})]
							}) : col.label
						}, col.key)), rowActions && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2.5 text-right font-medium text-muted-foreground",
							children: "Actions"
						})]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: tableContent })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-t border-border px-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground",
					children: [
						"Page ",
						currentPage,
						" of ",
						totalPages
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: currentPage <= 1,
						onClick: () => setPage(currentPage - 1),
						className: cn("rounded-md border border-input px-3 py-1.5 text-xs", currentPage <= 1 ? "text-muted-foreground opacity-60" : "hover:bg-muted"),
						children: "Previous"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: currentPage >= totalPages,
						onClick: () => setPage(currentPage + 1),
						className: cn("rounded-md border border-input px-3 py-1.5 text-xs", currentPage >= totalPages ? "text-muted-foreground opacity-60" : "hover:bg-muted"),
						children: "Next"
					})]
				})]
			})
		]
	});
}
function StatusBadge({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium", status === "Active" ? "bg-success text-success-foreground" : "bg-muted text-muted-foreground"),
		children: status
	});
}
function EntityRowActions({ slug, row }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-end gap-3 text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/records/$entity/$id",
			params: {
				entity: slug,
				id: row.id
			},
			className: "text-primary hover:underline",
			children: "Edit"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "text-muted-foreground hover:text-destructive",
			children: row.status === "Active" ? "Deactivate" : "Activate"
		})]
	});
}
function createEntityRowActions(slug) {
	return (row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityRowActions, {
		slug,
		row
	});
}
function EntityListPage({ slug }) {
	const entity = getEntity(slug);
	const [search, setSearch] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("all");
	const [loading] = (0, import_react.useState)(false);
	const rows = (0, import_react.useMemo)(() => {
		const q = search.trim().toLowerCase();
		return entity.rows.filter((row) => {
			const matchesStatus = status === "all" || row.status === status;
			const matchesSearch = !q || Object.entries(row).some(([k, v]) => k !== "id" && String(v).toLowerCase().includes(q));
			return matchesStatus && matchesSearch;
		});
	}, [
		entity.rows,
		search,
		status
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: entity.title,
		description: `Manage ${entity.title.toLowerCase()} across the distribution network.`,
		crumbs: [{ label: entity.title }],
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/records/$entity/$id",
			params: {
				entity: entity.slug,
				id: "new"
			},
			className: "inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Add New"]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
		columns: entity.columns,
		rows,
		loading,
		searchValue: search,
		onSearch: setSearch,
		statusFilter: status,
		onStatusFilter: setStatus,
		renderCell: (row, key) => key === "status" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: row.status }) : row[key],
		rowActions: createEntityRowActions(entity.slug)
	})] });
}
//#endregion
export { EntityListPage as t };
